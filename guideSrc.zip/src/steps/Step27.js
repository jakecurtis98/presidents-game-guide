const Step27 = {
    content: <>
        <h1>Now you are ready to play with your friends!</h1>
    </>

}

export default Step27;