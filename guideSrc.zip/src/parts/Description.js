function Description(props) {

    return (
        <div className={"explanationContainer"}>
            <h2>{props.children}</h2>
        </div>
    );
}



export default Description;