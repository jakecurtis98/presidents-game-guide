import Step0 from "./Step0";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Step3 from "./Step3";
import Step4 from "./Step4";
import Step5 from "./Step5";
import Step6 from "./Step6";
import Step7 from "./Step7";
import Step8 from "./Step8";
import Step9 from "./Step9";
import Step10 from "./Step10";
import Step11 from "./Step11";
import Step12_1 from "./Step12_1";
import Step12_2 from "./Step12_2";
import Step13_1 from "./Step13.1";
import Step13_2 from "./Step13.2";
import Step14 from "./Step14";
import Step15 from "./Step15";
import Step16 from "./Step16";
import Step17 from "./Step17";
import Step18 from "./Step18";
import Step19 from "./Step19";
import Step20 from "./Step20";
import Step21 from "./Step21";
import Step22 from "./Step22";
import Step23 from "./Step23";
import Step24 from "./Step24";
import Step25 from "./Step25";
import Step26 from "./Step26";
import Step27 from "./Step27";

const steps = [
        Step0,
        Step1(),
        Step2(),
        Step3(),
        Step4(),
        Step5(),
        Step6(),
        Step7(),
        Step8(),
        Step9(),
        Step10(),
        Step11(),
        Step12_1(),
        Step12_2(),
        Step13_1(),
        Step13_2(),
        Step14(),
        Step15(),
        Step16(),
        Step17(),
        Step18(),
        Step19(),
        Step20(),
        Step21(),
        Step22(),
        Step23(),
        Step24(),
        Step25(),
        Step26(),
        Step27,
    ];
export default steps;