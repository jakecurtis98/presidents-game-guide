rewrite ^category/$ https://superproof.co.uk/mouse-tales/ permanent;
rewrite ^wp-content/$ https://superproof.co.uk/wp-content/plugins/slidedeck2-personal/images/loading.png permanent;
rewrite ^bird-proofing-landing-page/$ https://superproof.co.uk/bird-proofing/ permanent;
rewrite ^how-superproofing-works/$ https://superproof.co.uk/how-to-get-rid-of-mice/ permanent;
rewrite ^how-to-get-rid-of-mice-superproof-explained/$ https://superproof.co.uk/how-to-get-rid-of-mice/ permanent;
rewrite ^how-superproofing-works-unique-mouse-control/$ https://superproof.co.uk/how-superproofing-works/ permanent;