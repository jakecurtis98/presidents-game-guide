function SpeechBubble(props) {

    return (
        <div className={"SpeechBubbleContainer"}>
            {props.children}
        </div>
    );
}



export default SpeechBubble;