function ExplanationArea(props) {

    return (
        <div className={"ExplanationAreaContainer"}>
            {props.children}
        </div>
    );
}



export default ExplanationArea;