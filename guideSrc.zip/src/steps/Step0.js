const Step0 = {
    content: <>
        <h1>Welcome!</h1>
        <h2>Guide to the President Game</h2>
    </>

}

export default Step0;